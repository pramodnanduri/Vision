import cv2
video=cv2.VideoCapture(0)
while True:

    check,frame=video.read()

    if not check:
        print("capture failed")

    face_casc=cv2.CascadeClassifier("frontface.xml")
    gray_face=cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces=face_casc.detectMultiScale(gray_face, scaleFactor=1.15, minNeighbors=5)

    for x,y,w,h in faces:
            frame=cv2.rectangle(frame, (x,y),(x+w,y+h),(0,255,0),3)

    if (len(faces)>0):
        print(str(len(faces))+" people ahead") 

video.release()

